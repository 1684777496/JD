package com.wj.jd

import android.app.AlertDialog
import android.app.ProgressDialog
import android.app.SharedElementCallback
import android.content.*
import kotlinx.android.synthetic.main.activity_main.*
import android.net.Uri
import android.os.Build
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.gson.Gson
import com.liulishuo.filedownloader.BaseDownloadTask
import com.liulishuo.filedownloader.FileDownloader
import com.wj.jd.bean.SimpleFileDownloadListener
import com.wj.jd.bean.VersionBean
import com.wj.jd.dialog.NewStyleDialog
import com.wj.jd.util.*
import com.wj.jd.widget.WidgetUpdateDataUtil
import com.wj.jd.widget.WidgetUpdateDataUtil1
import com.wj.jd.widget.WidgetUpdateDataUtil2
import com.zhy.base.fileprovider.FileProvider7
import java.io.File
import java.lang.Exception
import java.util.regex.Matcher
import java.util.regex.Pattern

class MainActivity : BaseActivity() {



    private lateinit var notificationUpdateReceiver: NotificationUpdateReceiver
    private lateinit var notificationUpdateReceiver1: NotificationUpdateReceiver1
    private lateinit var notificationUpdateReceiver2: NotificationUpdateReceiver2


    override fun setLayoutId(): Int {
        return R.layout.activity_main
    }

    override fun initView() {
        setTitle("京豆")
        back?.visibility = View.GONE
    }

    override fun initData() {
        /*checkAppUpdate()*/
        initNotification()
        startUpdateService()
    }


    private fun startUpdateService() {
        /*
        * app进入重新启动更新数据后台服务
        * */
        if ("1" != CacheUtil.getString("startUpdateService")) {
            WidgetUpdateDataUtil.updateWidget("ck")
            WidgetUpdateDataUtil1.updateWidget("ck1")
            WidgetUpdateDataUtil1.updateWidget("ck2")
        }
    }

    private fun initNotification() {
        val intentFilter = IntentFilter()
        intentFilter.addAction("com.scott.sayhi")
        notificationUpdateReceiver = NotificationUpdateReceiver()
        registerReceiver(notificationUpdateReceiver, intentFilter)

        val intentFilter1 = IntentFilter()
        intentFilter1.addAction("com.scott.sayhi1")
        notificationUpdateReceiver1 = NotificationUpdateReceiver1()
        registerReceiver(notificationUpdateReceiver1, intentFilter1)

        val intentFilter2 = IntentFilter()
        intentFilter2.addAction("com.scott.sayhi2")
        notificationUpdateReceiver2 = NotificationUpdateReceiver2()
        registerReceiver(notificationUpdateReceiver2, intentFilter2)
    }


   /*private fun checkAppUpdate() {
        HttpUtil.getAppVer(object : StringCallBack {
            override fun onSuccess(result: String) {
                try {
                    var gson = Gson()
                    val versionBean = gson.fromJson(result, VersionBean::class.java)
                    if (DeviceUtil.getAppVersionName().equals(versionBean.release)) {
                        Toast.makeText(this@MainActivity, "当前已是最新版本", Toast.LENGTH_SHORT).show()
                    } else {
                        if ("1" == versionBean.isUpdate) {
                            createDialog("版本更新", versionBean.content, "更新", object : NewStyleDialog.OnRightClickListener {
                                override fun rightClick() {
                                    downLoadApk(versionBean.content_url)
                                }
                            })
                        } else {
                            createDialog("版本更新", versionBean.content, "取消", "更新", object : NewStyleDialog.OnLeftClickListener {
                                override fun leftClick() {
                                    disMissDialog()
                                }
                            }, object : NewStyleDialog.OnRightClickListener {
                                override fun rightClick() {
                                    disMissDialog()
                                    downLoadApk(versionBean.content_url)
                                }
                            })
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onFail() {
            }

        })
    }

    //context.getExternalFilesDir()
    private fun downLoadApk(contentUrl: String?) {
        downLoad(contentUrl)
    }

    private lateinit var pd: ProgressDialog

    ///storage/emulated/0/Android/data/<包名>/files
    ///storage/emulated/0/Android/data/com.wj.jd/files
    private fun downLoad(contentUrl: String?) {
        if (TextUtils.isEmpty(contentUrl)) return

        pd = ProgressDialog(this)
        pd.setTitle("提示")
        pd.setMessage("软件版本更新中，请稍后...")
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL) //设置带进度条的

        pd.max = 100
        pd.setCancelable(false)
        pd.show()

        var pathParent = filesDir.path + "/downApk"
        var apkName = pathParent + System.currentTimeMillis() + ".apk"
        val file = File(pathParent)
        if (!file.exists()) {
            file.mkdirs()
        }

        FileDownloader.setup(this)
        FileDownloader.getImpl().create(contentUrl)
            .setPath(apkName)
            .setListener(object : SimpleFileDownloadListener() {
                override fun progress(task: BaseDownloadTask?, soFarBytes: Int, totalBytes: Int) {
                    val per = soFarBytes / (totalBytes / 100)
                    pd.progress = per
                }

                override fun completed(task: BaseDownloadTask) {
                    pd.dismiss()
                    val file = File(apkName)
                    installApk(file)
                }
            }).start()

    }

    private fun installApk(file: File) {
        val intent = Intent(Intent.ACTION_VIEW)
        FileProvider7.setIntentDataAndType(this, intent, "application/vnd.android.package-archive", file, true)
        startActivity(intent)
    }

*/

    override fun setEvent() {
        setting.setOnClickListener {
            val intent = Intent(this, SettingActivity::class.java)
            startActivity(intent)
        }

        muchCK.setOnClickListener {
            val intent = Intent(this, MuchCkActivity::class.java)
            startActivity(intent)
        }

        loginJd.setOnClickListener {
            val intent = Intent(this, MyWebActivity::class.java)
            startActivity(intent)


            val builder = AlertDialog.Builder(this)
            builder.setTitle("网页版获取CK教程")
            builder.setMessage("尊敬的用户您好：\n\n" +
                    "欢迎您使用网页版自动获取CK\n\n" +
                    "因为网页版本获取CK是电脑浏览器方式所以需要您将获取的CK做一下小改动\n\n" +
                    "在获取的pt_key=***;与pt_pin=***;中间会有一个空格请手动删除一下不然可能会影响小组件的正常运行\n\n")
            val alert = builder.create()
            alert.show()
        }


            val uri = Uri.parse("http://apk.tianxan.cn/new.apk")
            btnapp.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }


        updateCK.setOnClickListener {
            if (TextUtils.isEmpty(inputCK.text.toString())) {
                Toast.makeText(this, "CK为空，添加失败", Toast.LENGTH_SHORT).show()
            } else {
                CookieUtil.getCookie(inputCK.text.toString());
                CacheUtil.putString("ck", inputCK.text.toString())
                Toast.makeText(this, "CK添加成功", Toast.LENGTH_SHORT).show()
                inputCK.setText("")
                WidgetUpdateDataUtil.updateWidget("ck")
            }
            val builder = AlertDialog.Builder(this)
            builder.setTitle("APP使用说明")
            builder.setMessage("尊敬的用户您好：\n\n" +
                    "先此说明此项目为开源项目有能力的自己改动语法为Kotlin防止自己改动出现语法错误\n\n" +
                    "APP更新周期为7天所以请用户自己定时更新一下APP\n\n" +
                    "为了更好的使用APP遇到问题请及时加群反馈\n\n" +
                    "修改不易请多多支持！\n\n" +
                    "PS：APP后续会添加自动检测更新，谢谢")
            val alert = builder.create()
            alert.show()
        }



        addQQGroup.setOnClickListener {
            joinQQGroup("ziHdV6gAcUC3Hx0is1AaNEwAzfcaW8a4")
        }
    }

    /****************
     *
     * 发起添加群流程。群号：吃东哥绝户(466637624) 的 key 为： ziHdV6gAcUC3Hx0is1AaNEwAzfcaW8a4
     * 调用 joinQQGroup(ziHdV6gAcUC3Hx0is1AaNEwAzfcaW8a4) 即可发起手Q客户端申请加群 吃东哥绝户(466637624)
     *
     * @param key 由官网生成的key
     * @return 返回true表示呼起手Q成功，返回false表示呼起失败
     */
    fun joinQQGroup(key: String): Boolean {
        val intent = Intent()
        intent.data =
            Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26jump_from%3Dwebapi%26k%3D$key")
        // 此Flag可根据具体产品需要自定义，如设置，则在加群界面按返回，返回手Q主界面，不设置，按返回会返回到呼起产品界面    //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            startActivity(intent)
            true
        } catch (e: Exception) {
            // 未安装手Q或安装的版本不支持
            false
        }
    }


    inner class NotificationUpdateReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.i("====", "NotificationUpdateReceiver")
            WidgetUpdateDataUtil.updateWidget("ck")
        }
    }

    inner class NotificationUpdateReceiver1 : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.i("====", "NotificationUpdateReceiver1")
            WidgetUpdateDataUtil1.updateWidget("ck1")
        }
    }

    inner class NotificationUpdateReceiver2 : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.i("====", "NotificationUpdateReceiver1")
            WidgetUpdateDataUtil2.updateWidget("ck2")
        }
    }
}