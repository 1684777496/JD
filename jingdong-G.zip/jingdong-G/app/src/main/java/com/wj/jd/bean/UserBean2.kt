package com.wj.jd.bean

object UserBean2 {
    var nickName = ""
    var headImageUrl = ""
    var userLevel = ""
    var levelName = ""
    var beanNum = ""
    var todayBean = 0
    var ago1Bean = 0
    var ago2Bean = 0
    var ago3Bean = 0
    var ago4Bean = 0
    var ago5Bean = 0

    var hb = "--"
    var gqhb = "--"
    var jxiang = "--"
    var countdownTime = 0

    var isPlusVip = "0"

    var updateTips = ""
}