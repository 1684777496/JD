package com.wj.jd

/**
 * author wangjing
 * Date 2021/10/11
 * Description
 */
object Constants {
    var isDebug = false
}